package com.sergiolopez.rollermaniac

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
