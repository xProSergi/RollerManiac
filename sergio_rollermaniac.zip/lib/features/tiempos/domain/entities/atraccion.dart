class Atraccion {
  final String nombre;
  final int tiempoEspera;
  final bool operativa;

  Atraccion({
    required this.nombre,
    required this.tiempoEspera,
    required this.operativa,
  });
}